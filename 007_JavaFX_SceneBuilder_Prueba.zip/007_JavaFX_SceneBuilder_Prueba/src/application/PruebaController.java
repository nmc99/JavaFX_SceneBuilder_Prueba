package application;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class PruebaController {
	public Label lblcambiar;
	public TextField inputcambiar;

	public void cambiar() {
		System.out.println("-- Funcion cambiar --");
		String cambio = inputcambiar.getText().toString();
		lblcambiar.setText(cambio);
	}
}
